/** ITERATION
Create a for loop that will call and output the result of your method from Conditionals
2 10 times, using the current iteration as one of the parameters you pass to it. **/

public class Ex8 {

	public int iterationMethod(int Num1, int Num2) {
		int c = 0;
		if (Num1 == 0)
			c = Num2;
		if (Num2 == 0)
			c = Num1;
		else c = Num1 + Num2;
		return c;
	}
}
