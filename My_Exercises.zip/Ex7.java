/** CONDITIONALS 2
Modify your method from the previous task to have another if statement that checks
if one of the numbers is 0, if this is true then return the other non-0 number. **/
 
public class Ex7 {
	
	public int conditionMethod(int Num1, int Num2) {
		int c;
		if (Num1 == 0)
				c = Num2;
		if (Num2 == 0)
				c = Num1;
		else c = Num1 + Num2;
		return c;
	}

}
