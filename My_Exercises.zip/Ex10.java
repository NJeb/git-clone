
public class Ex10 {

}
