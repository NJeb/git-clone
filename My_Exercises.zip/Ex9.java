/** ARRAYS
Create an array that will hold 10 integer values, populate the array with values,
then call and output the result of your method from Conditionals 2, passing values
that are stored in the array as arguments to the method. **/

public class Ex9 {
	public int arrayMethod(int Num1, int Num2) {
		int c = 0;
		return c;
		
	}

}
