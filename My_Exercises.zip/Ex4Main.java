
public class Ex4Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex4 x= new Ex4();
		x.printEx4();

	}

}
