/** PARAMETERS
Create a method that accepts a string as a parameter, and then outputs that string
to the console via a System.out.println(), then call that method from your
main method. **/

public class Ex3 {
	
	public void print(String a) {
		System.out.println("Hello World");
	}

}
