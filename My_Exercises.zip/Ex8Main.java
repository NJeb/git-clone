
public class Ex8Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex8 x = new Ex8();
		for (int i = 0; i <=10; i++) {
			System.out.println(x.iterationMethod(i, 0));
			System.out.println(x.iterationMethod(0, i));
			System.out.println(x.iterationMethod(i, i));
		}
		

	}

}
