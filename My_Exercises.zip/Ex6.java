/** CONDITIONALS
Modify your method from the previous task to accept another parameter, a
Boolean, which if it is true, the method will return a sum of the two numbers, and if
it is false it will return the multiplication of the two numbers. **/

public class Ex6 {
	
	public int conditionMethod(int Num1, int Num2, boolean d) {
		int c;
		if(d== true)
			c= Num1 + Num2;
		else 
			c= Num1 * Num2;
		return c;
	}

}
