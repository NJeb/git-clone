/** BLACKJACK
Given 2 integer values greater than 0, return whichever value is closest to 21 without
going over 21. If they both go over 21 then return 0 **/

public class Ex12 {
	public void bMethod(int Num1, int Num2) {
		if (Num1 > 21 && Num2 > 21) {
			System.out.println("Invalid Numbers");
		}	
		else if(Num1 > 21) {
			System.out.println("First number is :" + Num1);
			
		}
		else if(Num2 > 21) {
			System.out.println("Second number is :" + Num2);
			
		}
		else if(Num1 > Num2) {
			System.out.println("First number is close to 21 :" + Num1);
		}
		
		else if(Num2 > Num1) {
			System.out.println("Second number is close to 21 :" + Num2);
		}
		return;

	}
}
