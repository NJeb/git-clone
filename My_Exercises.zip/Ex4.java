/** RETURN TYPES
Create a method to return �Hello World!� once called, which you call from your
main method, to then output the text to the screen.**/

public class Ex4 {
	
	public void printEx4() {
		System.out.println("Hello World");
		return;
		
	}

}
