
public class Ex3Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex3 x= new Ex3();
		x.print("Hello World");
		
	}

}
