
public class Ex6Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex6 a = new Ex6();
		int c = a.conditionMethod(3, 4, true);
		System.out.println(c);
		int d = a.conditionMethod(3, 4, false);
		System.out.println(d);
		
	}

}
