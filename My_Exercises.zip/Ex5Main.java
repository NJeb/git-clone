
public class Ex5Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex5 a = new Ex5();
		int add= a.addMethod(3,8);
		System.out.println(add);

	}

}
