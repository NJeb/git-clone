/** PARAMETERS/OPERATORS
Create a method that accepts two integers as parameters, then returns an integer
that is a sum of the two integers given, then call this method from your main method
and output the returned result.**/

public class Ex5 {
	
	public int addMethod(int Num1, int Num2) {
		int a= Num1;
		int b= Num2;
		int c= a + b;
		return c;
		
	}
	

}
