
public class Ex7Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex7 c = new Ex7();
		System.out.println(c.conditionMethod(4, 0));
		System.out.println(c.conditionMethod(0, 5));
		System.out.println(c.conditionMethod(4, 8));
		

	}

}
