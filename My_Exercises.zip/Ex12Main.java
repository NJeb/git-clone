
public class Ex12Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex12 b = new Ex12();
		b.bMethod(22, 22);
		b.bMethod(22, 21);
		b.bMethod(21, 22);
		b.bMethod(16, 18);
		b.bMethod(10, 8);
		
	}
}

