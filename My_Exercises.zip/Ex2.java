/** ASSIGNMENT
Store �Hello World!� in a variable, then output it to the console via a System.out.
println() statement in your main method.**/

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a= "Hello World";
		System.out.println(a);
		

	}

}
